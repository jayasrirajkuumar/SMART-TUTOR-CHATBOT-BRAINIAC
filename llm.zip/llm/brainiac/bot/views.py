from django.shortcuts import render, redirect
from .models import ChatMessage
from transformers import GPT2LMHeadModel, GPT2Tokenizer
from sentence_transformers import SentenceTransformer, util
import random
import json
import os
import openai
import time
from django.http import JsonResponse

# Load the SentenceTransformer model
model_st = SentenceTransformer('paraphrase-MiniLM-L6-v2')

# Set your OpenAI API key
openai.api_key = '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'

def load_intents():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    intents_path = os.path.join(current_dir, 'intents.json')
    
    with open(intents_path, 'r') as file:
        intents = json.load(file)
    return intents['intents']

def ask_openai(messages):
    """Query OpenAI API to answer the given question based on the conversation history."""
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=messages
        )
        chat_gpt_reply = response["choices"][0]["message"]["content"]
        return chat_gpt_reply
    except openai.error.RateLimitError:
        print("Rate limit reached. Please try again in 20 seconds.")
        time.sleep(20)
        return ask_openai(messages)

def get_response(intents, user_message, messages):
    max_score = 0
    best_intent = None

    for intent in intents:
        for pattern in intent['patterns']:
            embeddings = model_st.encode([user_message, pattern], convert_to_tensor=True)
            cosine_score = util.pytorch_cos_sim(embeddings[0], embeddings[1])

            if cosine_score.item() > max_score:
                max_score = cosine_score.item()
                best_intent = intent

    if max_score > 0.5 and best_intent:
        return random.choice(best_intent['responses'])
    else:
        messages.append({"role": "user", "content": user_message})
        bot_reply = ask_openai(messages)
        messages.append({"role": "assistant", "content": bot_reply})
        return bot_reply

def chatbot_view(request):
    intents = load_intents()  # Load intents

    # Initialize chat session on first access or refresh
    if 'chat_active' not in request.session:
        request.session['chat_messages'] = []
        request.session['chat_active'] = False

    if request.method == 'POST':
        user_message = request.POST.get('user_message', '')

        # Get the existing chat history from session
        messages = request.session.get('chat_messages', [])

        # Use the SentenceTransformer model to get a response based on the user_message
        bot_response = get_response(intents, user_message, messages)

        # Save messages to session
        messages.append({"role": "user", "content": user_message})
        messages.append({"role": "assistant", "content": bot_response})
        request.session['chat_messages'] = messages

        # Mark chat as active to differentiate from page refresh
        request.session['chat_active'] = True

        # Return bot_response as JSON
        return JsonResponse({'bot_response': bot_response})
    else:
        # If chat_active is False, clear the session to start fresh, indicating a page refresh or new access
        if not request.session.get('chat_active', False):
            request.session['chat_messages'] = []  # Reset chat messages
        request.session['chat_active'] = False  # Reset chat active flag for next refresh

    chat_messages = request.session.get('chat_messages', [])
    return render(request, 'index.html', {'chat_messages': chat_messages})
